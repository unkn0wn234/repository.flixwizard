# Disclaimer
This is not a mod like AuraMOD or anything in any sense I made very small changes for my use case but just made it a mod version so that it could be installed seperately in case people want to switch back to Arctic Horizon easily, as well as in the case I messed something up.

# Arctic Horizon [![License](https://img.shields.io/badge/License-GPLv3-blue)](https://github.com/jurialmunkey/skin.arctic.horizon/blob/master/LICENSE.txt) [![License](https://img.shields.io/badge/license-CC--NC--SA%204.0-green)](http://creativecommons.org/licenses/by-nc-sa/4.0/)


Kodi Versions:

- [Leia](https://github.com/jurialmunkey/skin.arctic.horizon/tree/leia)
- [Matrix](https://github.com/jurialmunkey/skin.arctic.horizon/tree/matrix)


The design portions of this work are licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 4.0 Unported License. To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/4.0/
or send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.

Icon images from iconmonstr.com see website for license terms

The code portions of this work are licensed under GPLv3
